<?php
/*
* @Created by: DUYNX
* @Author    : nguyenduypt86@gmail.com
* @Date      : 06/2016
* @Version   : 1.0
*/
namespace App\Http\Controllers\Admin;

use App\Http\Models\Images;
use App\Http\Models\Type;
use App\Library\PHPDev\ThumbImg;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Session;
use App\Http\Models\Category;
use App\Http\Models\Trash;
use App\Http\Controllers\BaseAdminController;
use App\Library\PHPDev\CGlobal;
use App\Library\PHPDev\Loader;
use App\Library\PHPDev\Pagging;
use App\Library\PHPDev\Utility;
use App\Library\PHPDev\ValidForm;

class ImagesController extends BaseAdminController{

    private $permission_view = 'images_view';
    private $permission_create = 'images_create';
    private $permission_edit = 'images_edit';
    private $permission_delete = 'images_delete';

	private $arrStatus = array(-1 => 'Chọn trạng thái', CGlobal::status_hide => 'Ẩn', CGlobal::status_show => 'Hiện');
	private $arrHot = array(-1 => 'Chọn hot', CGlobal::status_hide => 'Không', CGlobal::status_show => 'Có');
	private $arrFocus = array(-1 => 'Chọn nổi bật', CGlobal::status_hide => 'Không', CGlobal::status_show => 'Có');
	private $arrCate = array(-1=>'Chọn danh mục cha');
	private $strCategoryProduct = '';
	private $error = '';
	public function __construct(){
		parent::__construct();
		Loader::loadJS('backend/js/admin.js', CGlobal::$postEnd);
		Loader::loadCSS('libs/upload/cssUpload.css', CGlobal::$postHead);
		Loader::loadJS('libs/upload/jquery.uploadfile.js', CGlobal::$postEnd);
		Loader::loadJS('backend/js/upload-admin.js', CGlobal::$postEnd);
		Loader::loadJS('libs/dragsort/jquery.dragsort.js', CGlobal::$postHead);
		
		$typeId = Type::getIdByKeyword('group_images');
		$this->arrCate = CategoryController::getArrCategory($typeId);
	}
	public function listView(){

        if(!in_array($this->permission_view, $this->permission)){
            Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
            return Redirect::route('admin.dashboard');
        }

        //Config Page
		$pageNo = (int) Request::get('page', 1);
		$pageScroll = CGlobal::num_scroll_page;
		$limit = CGlobal::num_record_per_page;
		$offset = ($pageNo - 1) * $limit;
		$search = $data = array();
		$total = 0;
		
		$search['images_title'] = addslashes(Request::get('images_title', ''));
		$search['images_status'] = (int)Request::get('images_status', -1);
		$search['images_catid'] = (int)Request::get('images_catid', -1);
		$search['images_hot'] = (int)Request::get('images_hot', -1);
		$search['images_focus'] = (int)Request::get('images_focus', -1);
		$search['field_get'] = '';
		
		$dataSearch = Images::searchByCondition($search, $limit, $offset, $total);
		$paging = $total > 0 ? Pagging::getPager($pageScroll, $pageNo, $total, $limit, $search) : '';
		
		$optionStatus = Utility::getOption($this->arrStatus, $search['images_status']);
		$optionHot = Utility::getOption($this->arrHot, $search['images_hot']);
		$optionFocus = Utility::getOption($this->arrFocus, $search['images_focus']);
		$messages = Utility::messages('messages');
		
		$typeId = Type::getIdByKeyword('group_images');
		$this->strCategoryProduct = CategoryController::createOptionCategory($typeId, isset($search['images_catid']) ? $search['images_catid'] : 0);

        return view('admin.images.list',[
                    'data'=>$dataSearch,
                    'total'=>$total,
                    'paging'=>$paging,
                    'arrStatus'=>$this->arrStatus,
                    'optionStatus'=>$optionStatus,
                    'arrHot'=>$this->arrHot,
                    'optionHot'=>$optionHot,
                    'arrFocus'=>$this->arrFocus,
                    'optionFocus'=>$optionFocus,
                    'arrHot'=>$this->arrHot,
                    'optionHot'=>$optionHot,
                    'arrCate'=>$this->arrCate,
                    'strCategoryProduct'=>$this->strCategoryProduct,
                    'search'=>$search,
                    'messages'=>$messages,
                ]);
	}
	public function getItem($id=0){

        if(!in_array($this->permission_create, $this->permission) && !in_array($this->permission_edit, $this->permission)){
            Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
            return Redirect::route('admin.dashboard');
        }

		Loader::loadJS('libs/ckeditor/ckeditor.js', CGlobal::$postHead);

		$data = array();
		$images_image = '';
		$images_image_other = array();
		
		if($id > 0) {
			$data = Images::getById($id);
			if($data != null){
				if($data->images_image_other != ''){
                    $imagesImageOther = unserialize($data->images_image_other);
                    if(!empty($imagesImageOther)){
                        foreach($imagesImageOther as $k=>$v){
                            $url_thumb = ThumbImg::thumbBaseNormal(CGlobal::FOLDER_IMAGES, $id, $v, 400, 400, '', true, true);
                            $images_image_other[] = array('img_other'=>$v,'src_img_other'=>$url_thumb);
                        }
                    }
                }
                //Main Img
               $images_image = trim($data->images_image);
			}
		}
		$optionStatus = Utility::getOption($this->arrStatus, isset($data['images_status'])? $data['images_status'] : CGlobal::status_show);
		$optionHot = Utility::getOption($this->arrHot, isset($data['images_hot'])? $data['images_hot'] : -1);
		$optionFocus = Utility::getOption($this->arrFocus, isset($data['images_focus'])? $data['images_focus'] : 0);
		
		$typeId = Type::getIdByKeyword('group_images');
		$this->strCategoryProduct = CategoryController::createOptionCategory($typeId, isset($data['images_catid'])? $data['images_catid'] : 0);

        return view('admin.images.add',[
            'id'=>$id,
            'data'=>$data,
            'images_image'=>$images_image,
            'images_image_other'=>$images_image_other,
            'optionStatus'=>$optionStatus,
            'optionFocus'=>$optionFocus,
            'optionHot'=>$optionHot,
            'optionCategoryProduct'=>$this->strCategoryProduct,
            'error'=>$this->error,
        ]);
	}
	public function postItem($id=0){

        if(!in_array($this->permission_create, $this->permission) && !in_array($this->permission_edit, $this->permission)){
            Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
            return Redirect::route('admin.dashboard');
        }

		Loader::loadJS('libs/ckeditor/ckeditor.js', CGlobal::$postHead);

		$id_hiden = (int)Request::get('id_hiden', 0);
		$data = array();
		
		$dataSave = array(
				'images_title'=>array('value'=>addslashes(Request::get('images_title')), 'require'=>1, 'messages'=>'Tiêu đề không được trống!'),
				'images_intro'=>array('value'=>addslashes(Request::get('images_intro')),'require'=>0),
				'images_content'=>array('value'=>trim(Request::get('images_content')),'require'=>0),
				'images_order_no'=>array('value'=>(int)Request::get('images_order_no', 0),'require'=>0),
				'images_catid'=>array('value'=>(int)(Request::get('images_catid')),'require'=>0),
				'images_hot'=>array('value'=>(int)(Request::get('images_hot')),'require'=>0),
				'images_focus'=>array('value'=>(int)(Request::get('images_focus')),'require'=>0),
				'images_created'=>array('value'=>time(),'require'=>0),
				'images_status'=>array('value'=>(int)(Request::get('images_status')),'require'=>0),
				'images_image'=>array('value'=>trim(Request::get('image_primary')),'require'=>''),

				'images_name'=>array('value'=>trim(Request::get('images_name')),'require'=>''),
				'images_yearold'=>array('value'=>trim(Request::get('images_yearold')),'require'=>''),
				'images_address'=>array('value'=>trim(Request::get('images_address')),'require'=>''),

				'meta_title'=>array('value'=>trim(Request::get('meta_title')),'require'=>0),
				'meta_keywords'=>array('value'=>trim(Request::get('meta_keywords')),'require'=>0),
				'meta_description'=>array('value'=>trim(Request::get('meta_description')),'require'=>0),
				
		);
		
		//get images_cat_name, images_cat_alias
		if(isset($dataSave['images_catid']['value']) && $dataSave['images_catid']['value'] > 0){
			$arrCat = Category::getById($dataSave['images_catid']['value']);
			if($arrCat != null){
				$dataSave['images_cat_name']['value'] = $arrCat->category_title;
				$dataSave['images_cat_alias']['value'] = $arrCat->category_title_alias;
			}
		}
		
		//Main Img
		$image_primary = addslashes(Request::get('image_primary', ''));
		//Other Img
		$arrInputImgOther = array();
		$getImgOther = Request::get('img_other',array());
		if(!empty($getImgOther)){
			foreach($getImgOther as $k=>$val){
				if($val !=''){
					$arrInputImgOther[] = $val;
				}
			}
		}
		if (!empty($arrInputImgOther) && count($arrInputImgOther) > 0) {
			//Neu Ko chon Anh Chinh, Lay Anh Chinh La Cai Dau Tien
			$dataSave['images_image']['value'] = ($image_primary != '') ? $image_primary : $arrInputImgOther[0];
			$dataSave['images_image_other']['value'] = serialize($arrInputImgOther);
		}
		
		if($id > 0){
			unset($dataSave['images_created']);
		}
		
		$this->error = ValidForm::validInputData($dataSave);
		if($this->error == ''){
			$id = ($id == 0) ? $id_hiden : $id;

			Images::saveData($id, $dataSave);
			return Redirect::route('admin.images');
		}else{
			foreach($dataSave as $key=>$val){
				$data[$key] = $val['value'];
			}
		}
		
		$optionStatus = Utility::getOption($this->arrStatus, isset($data['images_status'])? $data['images_status'] : -1);
		$optionHot = Utility::getOption($this->arrHot, isset($data['images_hot'])? $data['images_hot'] : 0);
		$optionFocus = Utility::getOption($this->arrFocus, isset($data['images_focus'])? $data['images_focus'] : 0);
		
		$typeId = Type::getIdByKeyword('group_images');
		$this->strCategoryProduct = CategoryController::createOptionCategory($typeId, isset($data['images_catid'])? $data['images_catid'] : 0);

        return view('admin.images.add',[
                    'id'=>$id,
                    'data'=>$data,
                    'images_image'=>$image_primary,
                    'images_image_other'=>$arrInputImgOther,
                    'optionStatus'=>$optionStatus,
                    'optionFocus'=>$optionFocus,
                    'optionHot'=>$optionHot,
                    'optionCategoryProduct'=>$this->strCategoryProduct,
                    'error'=>$this->error,
                ]);
	}
	public function delete(){

        if(!in_array($this->permission_delete, $this->permission)){
            Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
            return Redirect::route('admin.dashboard');
        }

        $listId = Request::get('checkItem', array());
		$token = Request::get('_token', '');
		if(Session::token() === $token){
			if(!empty($listId) && is_array($listId)){
				foreach($listId as $id){
					Trash::addItem($id, 'Images', CGlobal::FOLDER_IMAGES, 'images_id', 'images_title', 'images_image', 'images_image_other');
                    Images::deleteId($id);
				}
				Utility::messages('messages', 'Xóa thành công!', 'success');
			}
		}
		return Redirect::route('admin.images');
	}
}