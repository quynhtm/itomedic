<?php
/*
* @Created by: DUYNX
* @Author    : nguyenduypt86@gmail.com
* @Date      : 06/2016
* @Version   : 1.0
*/
namespace App\Http\Controllers\Admin;

use App\Http\Models\QuestionAnswer;
use App\Http\Models\Type;
use App\Library\PHPDev\FuncLib;
use App\Library\PHPDev\ThumbImg;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Session;
use App\Http\Models\Category;
use App\Http\Models\Trash;
use App\Http\Controllers\BaseAdminController;
use App\Library\PHPDev\CGlobal;
use App\Library\PHPDev\Loader;
use App\Library\PHPDev\Pagging;
use App\Library\PHPDev\Utility;
use App\Library\PHPDev\ValidForm;

class QuestionAnswerController extends BaseAdminController{

	private $permission_view = 'questionAnswer_view';
	private $permission_create = 'questionAnswer_create';
	private $permission_edit = 'questionAnswer_edit';
	private $permission_delete = 'questionAnswer_delete';

	private $arrStatus = array(-1 => 'Chọn trạng thái', CGlobal::status_hide => 'Ẩn', CGlobal::status_show => 'Hiện');
	private $arrHot = array(-1 => 'Chọn hot', CGlobal::status_hide => 'Không', CGlobal::status_show => 'Có');
	private $arrFocus = array(-1 => 'Chọn nổi bật', CGlobal::status_hide => 'Không', CGlobal::status_show => 'Có');
	//private $arrType = array(-1 => 'Chọn kiểu', CGlobal::status_hide => 'Câu hỏi thường gặp', CGlobal::status_show => 'Bác sĩ tư vấn');
	private $arrCate = array(-1=>'Chọn danh mục cha');
	private $strCategoryProduct = '';
	private $error = '';
	public function __construct(){
		parent::__construct();
		Loader::loadJS('backend/js/admin.js', CGlobal::$postEnd);
		Loader::loadCSS('libs/upload/cssUpload.css', CGlobal::$postHead);
		Loader::loadJS('libs/upload/jquery.uploadfile.js', CGlobal::$postEnd);
		Loader::loadJS('backend/js/upload-admin.js', CGlobal::$postEnd);
		Loader::loadJS('libs/dragsort/jquery.dragsort.js', CGlobal::$postHead);
		Loader::loadCSS('libs/jAlert/jquery.alerts.css', CGlobal::$postHead);
		Loader::loadJS('libs/jAlert/jquery.alerts.js', CGlobal::$postEnd);

		$typeId = Type::getIdByKeyword('group_question_answer');
		$this->arrCate = CategoryController::getArrCategory($typeId);
	}
	public function listView(){


		if(!in_array($this->permission_view, $this->permission)){
			Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
			return Redirect::route('admin.dashboard');
		}
		//Config Page
		$pageNo = (int) Request::get('page', 1);
		$pageScroll = CGlobal::num_scroll_page;
		$limit = CGlobal::num_record_per_page;
		$offset = ($pageNo - 1) * $limit;
		$search = $data = array();
		$total = 0;
		
		$search['news_title'] = addslashes(Request::get('news_title', ''));
		$search['news_status'] = (int)Request::get('news_status', -1);
		$search['news_hot'] = (int)Request::get('news_hot', -1);
		$search['news_focus'] = (int)Request::get('news_focus', -1);
		$search['news_type'] = (int)Request::get('news_type', -1);
		$search['field_get'] = '';
		
		$dataSearch = QuestionAnswer::searchByCondition($search, $limit, $offset, $total);
		$paging = $total > 0 ? Pagging::getPager($pageScroll, $pageNo, $total, $limit, $search) : '';

		$optionStatus = Utility::getOption($this->arrStatus, $search['news_status']);
		$optionHot = Utility::getOption($this->arrHot, $search['news_hot']);
		$optionFocus = Utility::getOption($this->arrFocus, $search['news_focus']);
		$messages = Utility::messages('messages');
		
		$typeId = Type::getIdByKeyword('group_question_answer');
		$this->strCategoryProduct = CategoryController::createOptionCategory($typeId, isset($search['news_catid']) ? $search['news_catid'] : 0);
		//$optionType = Utility::getOption($this->arrType, $search['news_type']);

		return view('admin.questionAnswer.list',[
					'data'=>$dataSearch,
					'total'=>$total,
					'paging'=>$paging,
					'arrStatus'=>$this->arrStatus,
					'optionStatus'=>$optionStatus,
					'arrFocus'=>$this->arrFocus,
					'optionFocus'=>$optionFocus,
					'arrHot'=>$this->arrHot,
					'optionHot'=>$optionHot,
					//'optionType'=>$optionType,
					//'arrType'=>$this->arrType,
					'arrCate'=>$this->arrCate,
					'strCategoryProduct'=>$this->strCategoryProduct,
					'search'=>$search,
					'messages'=>$messages,
				]);
	}
	public function getItem($id=0){

		if(!in_array($this->permission_create, $this->permission) && !in_array($this->permission_edit, $this->permission)){
			Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
			return Redirect::route('admin.dashboard');
		}

		Loader::loadJS('libs/ckeditor/ckeditor.js', CGlobal::$postHead);

		$data = array();
		if($id > 0) {
			$data = QuestionAnswer::getById($id);
		}
		$optionStatus = Utility::getOption($this->arrStatus, isset($data['news_status'])? $data['news_status'] : CGlobal::status_show);
		$optionHot = Utility::getOption($this->arrHot, isset($data['news_hot'])? $data['news_hot'] : -1);
		$optionFocus = Utility::getOption($this->arrFocus, isset($data['news_focus'])? $data['news_focus'] : 0);

		$typeId = Type::getIdByKeyword('group_question_answer');
		$this->strCategoryProduct = CategoryController::createOptionCategory($typeId, isset($data['news_catid'])? $data['news_catid'] : 0);

		//$optionType = Utility::getOption($this->arrType, isset($data['news_type'])? $data['news_type'] : -1);

		return view('admin.questionAnswer.add',[
				'id'=>$id,
				'data'=>$data,
				'optionStatus'=>$optionStatus,
				'optionFocus'=>$optionFocus,
				'optionHot'=>$optionHot,
				//'optionType'=>$optionType,
				'optionCategoryProduct'=>$this->strCategoryProduct,
				'error'=>$this->error,
			]);

	}
	public function postItem($id=0){

		if(!in_array($this->permission_create, $this->permission) && !in_array($this->permission_edit, $this->permission)){
			Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
			return Redirect::route('admin.dashboard');
		}

		Loader::loadJS('libs/ckeditor/ckeditor.js', CGlobal::$postHead);

		$id_hiden = (int)Request::get('id_hiden', 0);
		$data = array();
		
		$dataSave = array(
				'news_title'=>array('value'=>addslashes(Request::get('news_title')), 'require'=>1, 'messages'=>'Tiêu đề không được trống!'),
				'news_name'=>array('value'=>addslashes(Request::get('news_name')), 'require'=>0),
				'news_name_doctor'=>array('value'=>addslashes(Request::get('news_name_doctor')), 'require'=>0),
				'news_tuoi'=>array('value'=>addslashes(Request::get('news_tuoi')), 'require'=>0),
				'news_phone'=>array('value'=>addslashes(Request::get('news_phone')), 'require'=>0),
				'news_mail'=>array('value'=>addslashes(Request::get('news_mail')), 'require'=>0),
				'news_address'=>array('value'=>addslashes(Request::get('news_address')), 'require'=>0),
				'news_question'=>array('value'=>addslashes(Request::get('news_question')),'require'=>0),
				'news_answer'=>array('value'=>trim(Request::get('news_answer')),'require'=>0),
				'news_order_no'=>array('value'=>(int)Request::get('news_order_no', 0),'require'=>0),
				'news_catid'=>array('value'=>(int)(Request::get('news_catid')),'require'=>0),
				'news_hot'=>array('value'=>(int)(Request::get('news_hot')),'require'=>0),
				'news_focus'=>array('value'=>(int)(Request::get('news_focus')),'require'=>0),
				'news_created'=>array('value'=>time(),'require'=>0),
				'news_status'=>array('value'=>(int)(Request::get('news_status')),'require'=>0),
				'news_image'=>array('value'=>trim(Request::get('image_primary')),'require'=>''),
				//'news_type'=>array('value'=>(int)(Request::get('news_type')),'require'=>0),

				'meta_title'=>array('value'=>trim(Request::get('meta_title')),'require'=>0),
				'meta_keywords'=>array('value'=>trim(Request::get('meta_keywords')),'require'=>0),
				'meta_description'=>array('value'=>trim(Request::get('meta_description')),'require'=>0),
				
		);
		//Get news_cat_name, news_cat_alias
		if(isset($dataSave['news_catid']['value']) && $dataSave['news_catid']['value'] > 0){
			$arrCat = Category::getById($dataSave['news_catid']['value']);
			if($arrCat != null){
				$dataSave['news_cat_name']['value'] = $arrCat->category_title;
				$dataSave['news_cat_alias']['value'] = $arrCat->category_title_alias;
			}
		}
		//Post Images Doctor
		$file = Input::file('image');
		if($file){
			$filename = $file->getClientOriginalName();
			$destinationPath = Config::get('config.DIR_ROOT').'/uploads/'.CGlobal::FOLDER_HOIDAP.'/'. $id;
			$upload  = Input::file('image')->move($destinationPath, $filename);
			if($filename != ''){
				$news_image_old = Request::get('news_image_old', '');
				if($news_image_old != ''){
					//xoa anh upload
					FuncLib::unlinkFileAndFolder($news_image_old, $id, 'uploads/'.CGlobal::FOLDER_HOIDAP, true);
				}
			}
			$dataSave['news_image']['value'] = $filename;
		}else{
			$dataSave['news_image']['value'] = Request::get('news_image', '');
		}

		//Post Images BenhNhan
		$file_benhnhan = Input::file('image_benhnhan');
		if($file_benhnhan){
			$filename_benhnhan = $file_benhnhan->getClientOriginalName();
			$destinationPathBenhNhan = Config::get('config.DIR_ROOT').'/uploads/'.CGlobal::FOLDER_HOIDAP.'/'. $id;
			$upload_benhnhan  = Input::file('image_benhnhan')->move($destinationPathBenhNhan, $filename_benhnhan);
			if($filename_benhnhan != ''){
				$news_image_benhnhan_old = Request::get('news_image_benhnhan_old', '');
				if($news_image_benhnhan_old != ''){
					//xoa anh upload
					FuncLib::unlinkFileAndFolder($news_image_benhnhan_old, $id, 'uploads/'.CGlobal::FOLDER_HOIDAP, true);
				}
			}
			$dataSave['news_image_benhnhan']['value'] = $filename_benhnhan;
		}else{
			$dataSave['news_image_benhnhan']['value'] = Request::get('news_image_benhnhan', '');
		}



		if($id > 0){
			unset($dataSave['news_created']);
		}
		
		$this->error = ValidForm::validInputData($dataSave);
		if($this->error == ''){
			$id = ($id == 0) ? $id_hiden : $id;

			QuestionAnswer::saveData($id, $dataSave);
			return Redirect::route('admin.questionAnswer');
		}else{
			foreach($dataSave as $key=>$val){
				$data[$key] = $val['value'];
			}
		}
		
		$optionStatus = Utility::getOption($this->arrStatus, isset($data['news_status'])? $data['news_status'] : -1);
		$optionHot = Utility::getOption($this->arrHot, isset($data['news_hot'])? $data['news_hot'] : 0);
		$optionFocus = Utility::getOption($this->arrFocus, isset($data['news_focus'])? $data['news_focus'] : 0);

		$typeId = Type::getIdByKeyword('group_question_answer');
		$this->strCategoryProduct = CategoryController::createOptionCategory($typeId, isset($data['news_catid'])? $data['news_catid'] : 0);

		//$optionType = Utility::getOption($this->arrType, isset($data['news_type'])? $data['news_type'] : -1);

		return view('admin.questionAnswer.add',[
				'id'=>$id,
				'data'=>$data,
				'optionStatus'=>$optionStatus,
				'optionFocus'=>$optionFocus,
				'optionHot'=>$optionHot,
				//'optionType'=>$optionType,
				'optionCategoryProduct'=>$this->strCategoryProduct,
				'error'=>$this->error,
			]);
	}
	public function delete(){

		if(!in_array($this->permission_delete, $this->permission)){
			Utility::messages('messages', 'Bạn không có quyền truy cập!', 'error');
			return Redirect::route('admin.dashboard');
		}

		$listId = Request::get('checkItem', array());
		$token = Request::get('_token', '');
		if(Session::token() === $token){
			if(!empty($listId) && is_array($listId)){
				foreach($listId as $id){
					Trash::addItem($id, 'QuestionAnswer', '', 'news_id', 'news_title', 'news_image', 'news_image_other');
					QuestionAnswer::deleteId($id);
				}
				Utility::messages('messages', 'Xóa thành công!', 'success');
			}
		}
		return Redirect::route('admin.questionAnswer');
	}
}