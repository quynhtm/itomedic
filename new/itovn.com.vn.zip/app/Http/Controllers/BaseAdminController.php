<?php
/*
* @Created by: HSS
* @Author	 : nguyenduypt86@gmail.com
* @Date 	 : 08/2016
* @Version	 : 1.0
*/
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;

use App\Http\Models\User;
use Illuminate\Support\Facades\View;

class BaseAdminController extends Controller{

	protected $user = array();
	protected $permission = array();
	public function __construct(){
        $this->middleware(function ($request, $next) {
            if(!User::isLogin()) {
                Redirect::route('login', array('url' => self::buildUrlEncode(URL::current())))->send();
            }
            $this->user = User::userLogin();
            if(sizeof($this->user)){
                if(sizeof($this->user['user_permission']) > 0) {
                    $this->permission = $this->user['user_permission'];
                }
            }
            View::share('aryPermission',$this->permission);
            View::share('menu',$this->menu());
            View::share('user',$this->user);
            return $next($request);
        });
	}

	public function menu(){

        $menu[] = array(
            'name'=>'QL nội dung', 'link'=>'javascript:void(0)', 'icon'=>'fa fa-angle-down',
            'sub'=>array(
                array('name'=>'Kiểu danh mục', 'controller'=>'Type' ,'link'=>URL::route('admin.type'), 'icon'=>'fa fa-folder-open icon-4x', 'showcontent'=>1, 'permission'=>'type_view'),
                array('name'=>'Danh mục', 'link'=>URL::route('admin.category'), 'icon'=>'fa fa-sitemap icon-4x', 'showcontent'=>1, 'permission'=>'category_view'),
                array('name'=>'Bài viết', 'controller'=>'News', 'link'=>URL::route('admin.news'), 'icon'=>'fa fa-file-text icon-4x', 'showcontent'=>1, 'permission'=>'news_view'),
                array('name'=>'Quảng cáo', 'controller'=>'Banner', 'link'=>URL::route('admin.banner'), 'icon'=>'fa fa-globe icon-4x', 'showcontent'=>1, 'permission'=>'banner_view'),
                array('name'=>'Liên hệ', 'controller'=>'Contact', 'link'=>URL::route('admin.contact'), 'icon'=>'fa fa-comments-o icon-4x', 'showcontent'=>0, 'permission'=>'contact_view'),
            ),
        );
        $menu[] = array(
            'name'=>'Sản phẩm', 'link'=>'javascript:void(0)', 'icon'=>'fa fa-angle-down',
            'sub'=>array(
                array('name'=>'Sản phẩm', 'controller'=>'Product', 'link'=>URL::route('admin.product'), 'icon'=>'fa fa-file icon-4x', 'showcontent'=>1, 'permission'=>'product_view'),
            ),
        );
        $menu[] = array(
            'name'=>'Hệ thống', 'link'=>'javascript:void(0)', 'icon'=>'fa fa-angle-down',
            'sub'=>array(
                array('name'=>'Danh sách quyền', 'controller'=>'Role', 'link'=>URL::route('admin.permission'), 'icon'=>'fa fa-gears icon-4x', 'showcontent'=>1, 'permission'=>'userPermission_view'),
                array('name'=>'Danh sách nhóm quyền', 'controller'=>'UserRole', 'link'=>URL::route('admin.role'), 'icon'=>'fa fa-group icon-4x', 'showcontent'=>1, 'permission'=>'userRole_view'),
                array('name'=>'Người dùng', 'controller'=>'User', 'link'=>URL::route('admin.user'), 'icon'=>'fa fa-user icon-4x', 'showcontent'=>1, 'permission'=>'user_view'),
                array('name'=>'Thông tin khác', 'controller'=>'Info', 'link'=>URL::route('admin.info'), 'icon'=>'fa fa-cogs icon-4x', 'showcontent'=>0, 'permission'=>'info_view'),
                array('name'=>'Thùng rác', 'controller'=>'Trash', 'link'=>URL::route('admin.trash'), 'icon'=>'fa fa-trash icon-4x', 'showcontent'=>1, 'permission'=>'trash_view'),
            ),
        );

		return $menu;
	}
}