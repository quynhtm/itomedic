<?php
/*
* @Created by: HSS
* @Author	 : nguyenduypt86@gmail.com
* @Date 	 : 08/2016
* @Version	 : 1.0
*/

namespace App\Http\Controllers\Site;

use App\Http\Controllers\BaseSiteController;
use App\Http\Models\Banner;
use App\Http\Models\Category;
use App\Http\Models\CommentProduct;
use App\Http\Models\Images;
use App\Http\Models\Info;
use App\Http\Models\News;
use App\Http\Models\Notify;
use App\Http\Models\Product;
use App\Http\Models\QuestionAnswer;
use App\Http\Models\Statics;
use App\Http\Models\Video;
use App\Library\PHPDev\CGlobal;
use App\Library\PHPDev\FuncLib;
use App\Library\PHPDev\Loader;
use App\Library\PHPDev\Pagging;
use App\Library\PHPDev\SEOMeta;
use App\Library\PHPDev\ThumbImg;
use App\Library\PHPDev\Utility;
use App\Library\PHPDev\ValidForm;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request;

class IndexController extends BaseSiteController{
	
	public function __construct(){
		parent::__construct();
	}
	public function index(){

        //Meta title
        $meta_title = '';
        $meta_keywords = '';
        $meta_description = '';
        $meta_img = '';
        $arrMeta = Info::getItemByKeyword('SITE_SEO_HOME');
        if (!empty($arrMeta)) {
            $meta_title = $arrMeta->meta_title;
            $meta_keywords = $arrMeta->meta_keywords;
            $meta_description = $arrMeta->meta_description;
            $meta_img = $arrMeta->info_img;
            if ($meta_img != '') {
                $meta_img = ThumbImg::thumbBaseNormal(CGlobal::FOLDER_INFO, $arrMeta->info_id, $arrMeta->info_img, 550, 0, '', true, true, false);
            }
        }
        SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);

        //Header h1-h5
        $texth1 = strip_tags(self::viewShareVal('SITE_TEXT_H1'));
        $texth2 = strip_tags(self::viewShareVal('SITE_TEXT_H2'));
        $texth3 = strip_tags(self::viewShareVal('SITE_TEXT_H3'));
        $texth4 = strip_tags(self::viewShareVal('SITE_TEXT_H4'));
        $texth5 = strip_tags(self::viewShareVal('SITE_TEXT_H5'));

        //Dich vu kham va dieu tri
        $catId3 = (int)strip_tags(self::viewShareVal('SITE_CAT_3'));
        $arrCat3 = $arrItemCat3 = array();
        if($catId3 > 0){
            $arrCat3 = Category::getById($catId3);
            $dataField3['news_catid'] = $catId3;
            $dataField3['news_focus'] = CGlobal::status_show;
            $dataField3['news_order_no_sort'] = 'asc';
            $arrItemCat3 = News::getNewsInCatID($dataField3, 12);
        }

        //Thiet bi vat ly y hoc co truyen
        $catId1 = (int)strip_tags(self::viewShareVal('SITE_CAT_1'));
        $arrCat1 = $arrItemCat1 = array();
        if($catId1 > 0){
            $arrCat1 = Category::getById($catId1);
            $dataField1['news_catid'] = $catId1;
            $dataField3['news_focus'] = CGlobal::status_show;
            $dataField3['news_order_no_sort'] = 'asc';
            $arrItemCat1 = News::getNewsInCatID($dataField1, 15);
        }

        //Thiet bi vat ly phuc hoi chuc nang
        $catId2 = (int)strip_tags(self::viewShareVal('SITE_CAT_2'));
        $arrCat2 = $arrItemCat2 = array();
        if($catId2 > 0){
            $arrCat2 = Category::getById($catId2);
            $dataField2['news_catid'] = $catId2;
            $arrItemCat2 = News::getNewsInCatID($dataField2, 24);
        }

        //Banner Partner
        $search['banner_status'] = CGlobal::status_show;
        $search['banner_type'] = 5;
        $search['field_get'] = 'banner_id,banner_title,banner_title_show,banner_intro,banner_image,banner_link,banner_is_target,banner_is_rel,banner_is_run_time,banner_start_time,banner_end_time';
        $dataPartner = Banner::getBannerSite($search, $limit = 100, 'partner');
        $dataPartner = $this->checkBannerShow($dataPartner);

        $messages = Utility::messages('messages');
		return view('site.content.index',[
            'texth1'=>$texth1,
            'texth2'=>$texth2,
            'texth3'=>$texth3,
            'texth4'=>$texth4,
            'texth5'=>$texth5,
            'arrCat3'=> $arrCat3,
            'arrItemCat3'=> $arrItemCat3,
            'arrCat1'=>$arrCat1,
            'arrItemCat1'=>$arrItemCat1,
            'arrCat2'=>$arrCat2,
            'arrItemCat2'=>$arrItemCat2,
            'dataPartner'=>$dataPartner,
            'messages'=>$messages,
        ]);
	}
    public function actionRouter($catname, $catid){
        if($catid > 0 && $catname != ''){
            $arrCat = Category::getById($catid);
            if($arrCat != null){
                $type_keyword = $arrCat->category_type_keyword;
                if($type_keyword == 'group_news'){
                    return self::pageNews($catname, $catid);
                }
                elseif($type_keyword == 'group_product'){
                    return self::pageProduct($catname, $catid);
                }
            }else{
                return Redirect::route('page.404');
            }
        }else{
            return Redirect::route('page.404');
        }
    }
    public function pageNews($catname, $catid){
        //Config Page
        $pageNo = (int)Request::get('page', 1);
        $pageScroll = CGlobal::num_scroll_page;
        $limit = CGlobal::num_record_per_page_news;
        $offset = ($pageNo - 1) * $limit;
        $search = $data = array();
        $total = 0;
        $paging = '';
        if ($catid > 0) {
            $search['news_cat_alias'] = $catname;
            $search['news_catid'] = $catid;
            $search['news_status'] = CGlobal::status_show;
            $search['news_ghim_order'] = 1;
            $search['field_get'] = 'news_id,news_title,news_catid,news_cat_name,news_cat_alias,news_intro,news_content,news_image,news_created,news_status,news_view_num';
            $data = News::searchByCondition($search, $limit, $offset, $total);
            $paging = $total > 0 ? Pagging::getPager($pageScroll, $pageNo, $total, $limit, $search) : '';
            $dataCate = Category::getById($catid);
        }
        if (sizeof($dataCate) != 0) {
            $meta_title = $dataCate->meta_title;
            $meta_keywords = $dataCate->meta_keywords;
            $meta_description = $dataCate->meta_description;
            SEOMeta::init('', $meta_title, $meta_keywords, $meta_description);
        }
        $theme = 'site.content.pageNews';
        return view($theme, [
           'data'=>$data,
           'dataCate'=>$dataCate,
           'paging'=>$paging,
        ]);
    }
    public function detailNews($name='', $id=0){
        $data = $dataSame = array();
        if($id > 0){
            $data = News::getById($id);
            if(sizeof($data) != 0){
                $dataField['field_get'] = '';
                $dataSame = News::getSameNews($dataField, $data->news_catid, $data->news_id, CGlobal::num_record_same_news);
                //Update View Num
                $dataUpdate['news_view_num'] = (int)$data->news_view_num + 1;
                News::updateData($id, $dataUpdate);
            }else{
                return Redirect::route('page.404');
            }
        }
        //Meta title
        if(sizeof($data) != 0){
            $meta_title = $data->meta_title;
            $meta_keywords = $data->meta_keywords;
            $meta_description = $data->meta_description;
            $meta_img = $data->news_image;
            if($meta_img != ''){
                $meta_img = ThumbImg::thumbBaseNormal(CGlobal::FOLDER_NEWS, $data->news_id, $data->news_image, 550, 0, '', true, true);
            }
            SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);
        }
        $theme = 'site.content.pageNewsDetail';
        return view($theme, ['data'=>$data, 'dataSame'=>$dataSame,]);
    }
    public function pageNewsSearch(){
        //Config Page
        $pageNo = (int)Request::get('page', 1);
        $pageScroll = CGlobal::num_scroll_page;
        $limit = CGlobal::num_record_per_page_news;
        $offset = ($pageNo - 1) * $limit;
        $search = $data = array();
        $total = 0;
        $paging = '';
        $keyword = addslashes(Request::get('news_title', ''));
        if ($keyword != '') {
            $search['news_title'] = $keyword;
            $search['news_status'] = CGlobal::status_show;
            $search['news_ghim_order'] = 1;
            $search['field_get'] = 'news_id,news_title,news_catid,news_cat_name,news_cat_alias,news_intro,news_content,news_image,news_created,news_status,news_view_num';
            $data = News::searchByCondition($search, $limit, $offset, $total);
            $paging = $total > 0 ? Pagging::getPager($pageScroll, $pageNo, $total, $limit, $search) : '';
        }
        $meta_title = 'Kết quả tìm kiếm';
        $meta_keywords = 'Kết quả tìm kiếm';
        $meta_description = 'Kết quả tìm kiếm';
        SEOMeta::init('', $meta_title, $meta_keywords, $meta_description);
        $theme = 'site.content.pageNewsSearch';
        return view($theme, [
            'data'=>$data,
            'paging'=>$paging,
            'keyword'=>$keyword,
        ]);
    }
    public function pageProduct($catname, $catid){
        //Config Page
        $pageNo = (int) Request::get('page', 1);
        $pageScroll = CGlobal::num_scroll_page;
        $limit = CGlobal::num_record_per_page_product;
        $offset = ($pageNo - 1) * $limit;
        $search = $data = $dataCate = array();
        $total = 0;
        $paging = '';
        if($catid > 0){
            $searchPr['product_cat_alias'] = $catname;
            $searchPr['product_catid'] = $catid;
            $searchPr['product_status'] = CGlobal::status_show;
            $searchPr['product_ghim_order'] = CGlobal::status_show;
            $searchPr['field_get'] = '';
            $data = Product::searchByCondition($searchPr, $limit, $offset, $total);
            $paging = $total > 0 ? Pagging::getPager($pageScroll, $pageNo, $total, $limit, $searchPr) : '';
            $dataCate = Category::getById($catid);
        }
        if(sizeof($dataCate) != 0){
            $meta_title = $dataCate->meta_title;
            $meta_keywords = $dataCate->meta_keywords;
            $meta_description = $dataCate->meta_description;
            SEOMeta::init('', $meta_title, $meta_keywords, $meta_description);
        }
        return view('site.content.pageProduct',[
            'catid'=>$catid,
            'dataCate'=>$dataCate,
            'data'=>$data,
            'paging'=>$paging,
        ]);

    }
    public function detailProduct($name='', $id=0){
        Loader::loadJS('libs/slidermagnific/magnific-popup.min.js', CGlobal::$postEnd);
        Loader::loadCSS('libs/slidermagnific/magnific-popup.css', CGlobal::$postHead);
        $data = $dataSame = array();
        if($id > 0){
            $data = Product::getById($id);
            if(sizeof($data) == 0){
                return Redirect::route('page.404');
            }
        }
        //Meta title
        if(sizeof($data) != 0){
            $meta_title = $data->meta_title;
            $meta_keywords = $data->meta_keywords;
            $meta_description = $data->meta_description;
            $meta_img = $data->product_image;
            if($meta_img != ''){
                $meta_img = ThumbImg::thumbBaseNormal(CGlobal::FOLDER_PRODUCT, $data->product_id, $data->product_image, 550, 0, '', true, true);
            }
            $dataSame = Product::getSameProduct(array(), $data->product_catid, $data->product_id, 4);
            SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);
        }

        return view('site.content.pageProductDetail', ['data'=>$data,'dataSame'=>$dataSame]);

    }
    public function pageProductSearch(){
        $meta_title = $meta_keywords = $meta_description = 'Kết quả tìm kiếm';
        $meta_img = '';
        $arrMeta = Info::getItemByKeyword('SITE_SEO_SEARCH');
        if(sizeof($arrMeta) > 0){
            $meta_title = $arrMeta->meta_title;
            $meta_keywords = $arrMeta->meta_keywords;
            $meta_description = $arrMeta->meta_description;
            $meta_img = $arrMeta->info_img;
            if($meta_img != ''){
                $meta_img = ThumbImg::thumbBaseNormal(CGlobal::FOLDER_INFO, $arrMeta->info_id, $arrMeta->info_img, 550, 0, '', true, true);
            }
        }
        SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);

        //Config Page
        $pageNo = (int) Request::get('page', 1);
        $pageScroll = CGlobal::num_scroll_page;
        $limit = CGlobal::num_record_per_page_product;
        $offset = ($pageNo - 1) * $limit;
        $search = $data = array();
        $total = 0;
        $paging = '';

        $keyword = addslashes(Request::get('product_title', ''));
        if($keyword != ''){
            $search['product_title'] = $keyword;
            $search['product_status'] = CGlobal::status_show;
            $search['product_ghim_order'] = 1;
            $search['field_get'] = '';
            $data = Product::searchByCondition($search, $limit, $offset, $total);
            $paging = $total > 0 ? Pagging::getPager($pageScroll, $pageNo, $total, $limit, $search) : '';
        }

        return view('site.content.pageProductSearch',[
            'data'=>$data,
            'paging'=>$paging,
            'keyword'=>$keyword
        ]);
    }
}
