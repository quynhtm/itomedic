<?php
/*
* @Created by: HSS
* @Author	 : nguyenduypt86@gmail.com
* @Date 	 : 08/2016
* @Version	 : 1.0
*/
namespace App\Http\Controllers\Site;
use App\Http\Controllers\BaseSiteController;
use App\Http\Models\Contact;
use App\Http\Models\EmailCustomer;
use App\Http\Models\EmailCustomerGift;
use App\Http\Models\Info;
use App\Http\Models\QuestionAnswer;
use App\Library\PHPDev\CGlobal;
use App\Library\PHPDev\FuncLib;
use App\Library\PHPDev\Loader;
use App\Library\PHPDev\SEOMeta;
use App\Library\PHPDev\ThumbImg;
use App\Library\PHPDev\Utility;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request;

class StaticController extends BaseSiteController{
	
	public function __construct(){
		parent::__construct();
	}

	public function pageContact(){

		$arrContact = Info::getItemByKeyword('SITE_CONTACT');
		$messages = Utility::messages('messages');

        if(sizeof($arrContact) > 0){
            $meta_title = $arrContact->meta_title;
            $meta_keywords = $arrContact->meta_keywords;
            $meta_description = $arrContact->meta_description;
            $meta_img = $arrContact->info_img;
            if($meta_img != ''){
                $meta_img = ThumbImg::thumbBaseNormal(CGlobal::FOLDER_INFO, $arrContact->info_id, $arrContact->info_img, 550, 0, '', true, true);
            }
            SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);
		}
		
		if(sizeof($_POST) > 0){
            $contact_title = addslashes(Request::get('txtName', ''));
            $contact_phone = addslashes(Request::get('txtMobile', ''));
            $contact_address = addslashes(Request::get('txtAddress', ''));
            $contact_content = addslashes(Request::get('txtMessage', ''));
            $contact_mail = addslashes(Request::get('txtMail', ''));
            $contact_created = time();
            if($contact_title != '' && $contact_phone !='' && $contact_content !=''){
                $dataInput = array(
                    'contact_title'=>$contact_title,
                    'contact_phone'=>$contact_phone,
                    'contact_address'=>$contact_address,
                    'contact_email'=>$contact_mail,
                    'contact_content'=>$contact_content,
                    'contact_created'=>$contact_created,
                    'contact_status'=>0
                );
                $query = Contact::addData($dataInput);
                if($query > 0){
                    $messages = Utility::messages('messages', 'Cảm ơn bạn đã gửi thông tin liên hệ. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất!');
                    return Redirect::route('site.pageContact');
                }
            }
		}
        return view('site.content.pageContact',[
                    'arrContact'=>$arrContact,
                    'messages'=>$messages
                ]);
	}
    public function pageBooking(){
        if(sizeof($_POST) > 0){
            $book_name = addslashes(Request::get('txtName', ''));
            $book_mail = addslashes(Request::get('txtMail', ''));
            $book_phone = addslashes(Request::get('txtMobile', ''));
            $book_address = addslashes(Request::get('txtAddress', ''));
            $book_content = addslashes(Request::get('txtMessage', ''));

            if($book_name != '' && $book_phone !=''){
                $dataInput = array(
                    'customer_full_name'=>$book_name,
                    'customer_email'=>$book_mail,
                    'customer_phone'=>$book_phone,
                    'customer_address'=>$book_address,
                    'customer_content'=>$book_content
                );
                $query = EmailCustomer::addData($dataInput);
                if($query > 0){
                    $messages = Utility::messages('messages', 'Cảm ơn bạn đã đặt lịch tư vấn. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất!');
                    return Redirect::route('site.index');
                }
            }else{
                $messages = Utility::messages('messages', 'Bạn chưa nhập đủ thông tin. Vui lòng nhập lại!');
                return Redirect::route('site.index');
            }
        }else{
            return Redirect::route('site.index');
        }
    }
    public function pageOrder(){
        if(sizeof($_POST) > 0){
            $txtProductId = addslashes(Request::get('txtProductId', ''));
            $txtProductName = addslashes(Request::get('txtProductName', ''));
            $txtProductNum = addslashes(Request::get('txtProductNum', 0));
            $txtProductOther = addslashes(Request::get('txtProductOther', ''));
            $txtName = addslashes(Request::get('txtName', ''));
            $txtMobile = addslashes(Request::get('txtMobile', ''));
            $txtAddress = addslashes(Request::get('txtAddress', ''));
            if($txtMobile != '' && $txtAddress != '' && $txtProductId > 0){

                $content = 'Khách hàng đặt mua sản phẩm:<br>';
                $content .= 'Tên sản phẩm:'.$txtProductName.'<br/> Số lượng'. $txtProductNum.'<br/>';
                $content .= 'Mua thêm sản phẩm khác:'.$txtProductOther.'<br/>';

                $data = array(
                    'customer_full_name'=>$txtName,
                    'customer_phone'=>$txtMobile,
                    'customer_address'=>$txtAddress,
                    'customer_content'=>$content,
                );
                EmailCustomerGift::addData($data);
            }

            $messages = Utility::messages('messages', 'Cảm ơn bạn đã hàng. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất!');
            return Redirect::route('site.pageThanks');
        }else{
            return Redirect::route('site.index');
        }
    }
    public function pageThanks(){
        $arrThanks = Info::getItemByKeyword('SITE_THANKS');
        $content = '';
        if(sizeof($arrThanks) > 0){
            $meta_title = $arrThanks->meta_title;
            $meta_keywords = $arrThanks->meta_keywords;
            $meta_description = $arrThanks->meta_description;
            $meta_img = $arrThanks->info_img;
            $content = stripcslashes($arrThanks->info_content);
            if($meta_img != ''){
                $meta_img = ThumbImg::thumbBaseNormal(CGlobal::FOLDER_INFO, $arrThanks->info_id, $arrThanks->info_img, 550, 0, '', true, true);
            }
            SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);
        }

        return view('site.content.pageThanks', ['content'=>$content]);
    }
    public function pageDangKyUngTuyen(){
        $messages = Utility::messages('messages');

        $meta_title = 'Đăng ký tuyển dụng';
        $meta_keywords = 'Đăng ký tuyển dụng';
        $meta_description = 'Đăng ký tuyển dụng';
        $meta_img = '';
        SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);

        if(sizeof($_POST) > 0){

            $contact_title = addslashes(Request::get('txtName', ''));
            $contact_phone = addslashes(Request::get('txtMobile', ''));
            $txtChucVu = (int)Request::get('txtChucVu',-1);
            $contact_mail = addslashes(Request::get('txtMail', ''));
            $contact_created = time();
            if($contact_title != '' && $contact_phone !=''){
                $dataInput = array(
                    'contact_title'=>'Người đăng ký ứng tuyển: ' . $contact_title,
                    'contact_phone'=>$contact_phone,
                    'contact_email'=>$contact_mail,
                    'contact_content'=>'Chức vụ: ' . (isset(CGlobal::$arrChucVu[$txtChucVu])) ? CGlobal::$arrChucVu[$txtChucVu] : 'Chưa xác định',
                    'contact_created'=>$contact_created,
                    'contact_status'=>0
                );
                $query = Contact::addData($dataInput);
                if($query > 0){
                    $messages = Utility::messages('messages', 'Cảm ơn bạn đã gửi thông tin ứng tuyển. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất!');
                    return Redirect::route('site.pageDangKyUngTuyen');
                }
            }
        }


        return view('site.content.pageDangKyUngTuyen', ['messages'=>$messages]);
    }
}
