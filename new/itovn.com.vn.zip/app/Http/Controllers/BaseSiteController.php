<?php
/*
* @Created by: HSS
* @Author	 : nguyenduypt86@gmail.com
* @Date 	 : 08/2016
* @Version	 : 1.0
*/
namespace App\Http\Controllers;

use App\Http\Models\Banner;
use App\Http\Models\Category;
use App\Http\Models\CommentProduct;
use App\Http\Models\Info;
use App\Http\Models\Member;
use App\Http\Models\News;
use App\Http\Models\Type;
use App\Http\Models\Video;
use App\Library\PHPDev\CGlobal;
use App\Library\PHPDev\FuncLib;
use App\Library\PHPDev\Loader;
use App\Library\PHPDev\SEOMeta;
use App\Library\PHPDev\Utility;
use App\Library\PHPDev\ValidForm;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\View;

class BaseSiteController extends Controller{
    protected $member = array();

    public function __construct(){
        Loader::loadJS('frontend/js/site.js', CGlobal::$postEnd);
        Loader::loadJS('frontend/js/main.js', CGlobal::$postEnd);
        Loader::loadJS('frontend/js/responsiveslides.min.js', CGlobal::$postEnd);
        Loader::loadCSS('libs/fontAwesome/css/font-awesome.min.css', CGlobal::$postHead);

        //Banner Head
        $search['banner_status'] = CGlobal::status_show;
        $search['banner_type'] = 0;
        $search['field_get'] = 'banner_id,banner_title,banner_title_show,banner_intro,banner_image,banner_link,banner_is_target,banner_is_rel,banner_is_run_time,banner_start_time,banner_end_time';
        $dataBannerHead = Banner::getBannerSite($search, $limit=1, 'header');
        $dataBannerHead = $this->checkBannerShow($dataBannerHead);
        View::share('dataBannerHead',$dataBannerHead);

        //BannerSlider
        $search['banner_status'] = CGlobal::status_show;
        $search['banner_type'] = 1;
        $search['field_get'] = 'banner_id,banner_title,banner_title_show,banner_intro,banner_image,banner_link,banner_is_target,banner_is_rel,banner_is_run_time,banner_start_time,banner_end_time';
        $dataBanner = Banner::getBannerSite($search, $limit = 15, 'slider');
        $dataBanner = $this->checkBannerShow($dataBanner);
        View::share('dataBanner',$dataBanner);

        //List Category
        $dataField['field_get'] = '';
        $arrCategory = Category::getAllCategory(0, array(), 0);
        View::share('arrCategory',$arrCategory);

        $textaddress = self::viewShareVal('SITE_FOOTER_LEFT');
        View::share('textaddress',$textaddress);

        $textTime = self::viewShareVal('SITE_FOOTER_RIGHT');
        View::share('textTime',$textTime);

        $textCopyRight = self::viewShareVal('SITE_FOOTER_COPYRIGHT');
        View::share('textCopyRight',$textCopyRight);

        $arr_news_desc = self::getNewsDesc(5);
        View::share('arr_news_desc',$arr_news_desc);

        $arr_news_desc_footer = self::getNewsDesc(3);
        View::share('arr_news_desc_footer',$arr_news_desc_footer);

    }
    public static function viewShareVal($key='', $showfull=''){
        $str='';
        if($key != '') {
            $arrStr = Info::getItemByKeyword($key);
            if (sizeof($arrStr) > 0) {
                if($showfull == 1){
                    return $arrStr;
                }else{
                    $str = stripslashes($arrStr->info_content);
                }
            }
        }
       return $str;
    }
    public static function checkBannerShow($data = array()){
        $result = array();
        foreach ($data as $k => $item){
            if ($item->banner_is_rel == 0) {
                $rel = 'rel="nofollow"';
            } else {
                $rel = '';
            }

            if ($item->banner_is_target == 0) {
                $target = 'target="_blank"';
            } else {
                $target = '';
            }

            $banner_is_run_time = 1;
            if ($item->banner_is_run_time == CGlobal::status_hide) {
                $banner_is_run_time = 1;
            }else {
                $banner_start_time = $item->banner_start_time;
                $banner_end_time = $item->banner_end_time;
                $date_current = time();
                if ($banner_start_time > 0 && $banner_end_time > 0 && $banner_start_time <= $banner_end_time) {
                    if ($banner_start_time <= $date_current && $date_current <= $banner_end_time) {
                        $banner_is_run_time = 1;
                    }
                } else {
                    $banner_is_run_time = 0;
                }
            }

            if($item->banner_image != '' && $banner_is_run_time == 1) {
                $_item = array(
                    'banner_id' => $item->banner_id,
                    'banner_intro' => strip_tags(trim($item->banner_intro)),
                    'banner_link' => $item->banner_link,
                    'banner_title_show' => $item->banner_title_show,
                    'banner_image' => $item->banner_image,
                    'rel' => $rel,
                    'target' => $target,
                    'banner_is_run_time' => $banner_is_run_time,
                );
                $result[] = $_item;
            }
        }
        return $result;
    }
    public static function getNewsDesc($litmit=5){
        $dataField['field_get'] = 'news_id,news_title,news_image,news_cat_name';
        $result = News::getNewsDesc($dataField, $litmit);
        return $result;
    }
    public function page403(){
		$meta_img='';
		$meta_title = $meta_keywords = $meta_description = $txt403 = CGlobal::txt403;
		SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);
		return view('errors.page-403',['txt403'=>$txt403]);
	}
	public function page404(){
        $meta_img='';
        $meta_title = $meta_keywords = $meta_description = $txt404 = CGlobal::txt404;
        SEOMeta::init($meta_img, $meta_title, $meta_keywords, $meta_description);
        return view('errors.page-404',['txt404'=>$txt404]);
	}
}  