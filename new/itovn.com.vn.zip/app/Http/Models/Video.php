<?php
/*
* @Created by: DUYNX
* @Author    : nguyenduypt86@gmail.com
* @Date      : 06/2016
* @Version   : 1.0
*/
namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\Library\PHPDev\CGlobal;
use App\Library\PHPDev\Memcache;
use App\Library\PHPDev\Utility;

class Video extends Model{
    
    protected $table = 'video';
    protected $primaryKey = 'video_id';
    public  $timestamps = false;
    protected $fillable = array(
	    	'video_id', 'video_catid', 'video_cat_name', 'video_cat_alias','video_title', 'video_title_alias', 'video_intro',
    		'video_content', 'video_image', 'video_image_other', 'video_link_youtube', 'video_file', 'video_created', 'video_hot','video_focus', 'video_order_no',
    		'video_view_num', 'video_status', 'video_name', 'video_address', 'video_yearold', 'meta_title', 'meta_keywords', 'meta_description',
    );
    //ADMIN
  	public static function searchByCondition($dataSearch=array(), $limit=0, $offset=0, &$total){
	  	try{
	  		
	  		$query = Video::where('video_id','>',0);
	  		
	  		if (isset($dataSearch['video_id']) && $dataSearch['video_id'] != '') {
	  			$query->where('video_id','=', $dataSearch['video_id']);
	  		}
	  		
	  		if (isset($dataSearch['video_title']) && $dataSearch['video_title'] != '') {
	  			$query->where('video_title','LIKE', '%' . $dataSearch['video_title'] . '%');
	  		}
	  		
	  		if(isset($dataSearch['video_catid']) && $dataSearch['video_catid'] != -1){
	  			$catid = $dataSearch['video_catid'];
	  			$arrCat = array($catid);
	  			Category::makeListCatId($catid, 0, $arrCat);
	  			if(is_array($arrCat) && !empty($arrCat)){
	  				$query->whereIn('video_catid', $arrCat);
	  			}
	  		}
	  		
	  		if (isset($dataSearch['video_status']) && $dataSearch['video_status'] != -1){
	  			$query->where('video_status', $dataSearch['video_status']);
	  		}
	  		
	  		if (isset($dataSearch['video_hot']) && $dataSearch['video_hot'] != -1) {
	  			$query->where('video_hot', $dataSearch['video_hot']);
	  		}
	  		
	  		if (isset($dataSearch['video_focus']) && $dataSearch['video_focus'] != -1) {
	  			$query->where('video_focus', $dataSearch['video_focus']);
	  		}
	  		
	  		$total = $query->count();
	  		$query->orderBy('video_id', 'desc');
	  	
	  		$fields = (isset($dataSearch['field_get']) && trim($dataSearch['field_get']) != '') ? explode(',',trim($dataSearch['field_get'])): array();
	  		if(!empty($fields)){
	  			$result = $query->take($limit)->skip($offset)->get($fields);
	  		}else{
	  			$result = $query->take($limit)->skip($offset)->get();
	  		}
	  		return $result;
	  	
	  	}catch (PDOException $e){
	  		throw new PDOException();
	  	}
  	}
  	
  	public static function getById($id=0){
  		$result = (Memcache::CACHE_ON) ? Cache::get(Memcache::CACHE_VIDEO_ID.$id) : array();
  		try {
  			if(empty($result)){
	  			$result = Video::where('video_id', $id)->first();
	  			if($result && Memcache::CACHE_ON){
	  				Cache::put(Memcache::CACHE_VIDEO_ID.$id, $result, Memcache::CACHE_TIME_TO_LIVE_ONE_MONTH);
	  			}
	  		}
	  	} catch (PDOException $e) {
	  		throw new PDOException();
	  	}
	  	return $result;
  	}
  	
  	public static function updateData($id=0, $dataInput=array()){
  		try {
  			DB::connection()->getPdo()->beginTransaction();
  			$data = Video::find($id);
  			if($id > 0 && !empty($dataInput)){
  				$data->update($dataInput);
  				if(isset($data->video_id) && $data->video_id > 0){
  					self::removeCacheId($data->video_id);
  				}
  			}
  			DB::connection()->getPdo()->commit();
  			return true;
  		} catch (PDOException $e) {
  			DB::connection()->getPdo()->rollBack();
  			throw new PDOException();
  		}
  	}
  	
  	public static function addData($dataInput=array()){
        try {
            DB::connection()->getPdo()->beginTransaction();
            $data = new Video();
            if (is_array($dataInput) && count($dataInput) > 0) {
                foreach ($dataInput as $k => $v) {
                    $data->$k = $v;
                }
            }
            if ($data->save()) {
                DB::connection()->getPdo()->commit();
                if($data->video_id && Memcache::CACHE_ON){
                	video::removeCacheId($data->video_id);
                }
                return $data->video_id;
            }
            DB::connection()->getPdo()->commit();
            return false;
        } catch (PDOException $e) {
            DB::connection()->getPdo()->rollBack();
            throw new PDOException();
        }
    }

    public static function saveData($id=0, $data=array()){
    	$data_post = array();
    	if(!empty($data)){
    		foreach($data as $key=>$val){
    			$data_post[$key] = $val['value'];
    		}
    	}
    	if($id > 0){
    		Video::updateData($id, $data_post);
    		Utility::messages('messages', 'Cập nhật thành công!');
    	}else{
    		Video::addData($data_post);
    		Utility::messages('messages', 'Thêm mới thành công!');
    	}
 
    }
    
  	public static function deleteId($id=0){
  		try {
  			DB::connection()->getPdo()->beginTransaction();
  			$data = Video::find($id);
  			if($data != null){
  				//Remove Img
  				$video_image_other = ($data->video_image_other != '') ? unserialize($data->video_image_other) : array();
  				if(is_array($video_image_other) && !empty($video_image_other)){
  					$path = Config::get('config.DIR_ROOT').'uploads/'.CGlobal::FOLDER_VIDEO.'/'.$id;
  					foreach($video_image_other as $v){
  						if(is_file($path.'/'.$v)){
  							@unlink($path.'/'.$v);
  						}
  					}
  					if(is_dir($path)) {
  						@rmdir($path);
  					}
  				}
  				//End Remove Img
  				$data->delete();
  				if(isset($data->video_id) && $data->video_id > 0){
  					self::removeCacheId($data->video_id);
  				}
  				DB::connection()->getPdo()->commit();
  			}
  			return true;
  		} catch (PDOException $e) {
  			DB::connection()->getPdo()->rollBack();
  			throw new PDOException();
  		}
  	}
  	
  	public static function removeCacheId($id=0){
  		if($id>0){
  			Cache::forget(Memcache::CACHE_VIDEO_ID.$id);
  		}
  	}
  	
  	//SITE
  	public static function getSameVideo($dataField='', $catid=0, $id=0, $limit=10){
  		$result = array();
  		try{
  			if($catid > 0 && $id > 0 && $limit > 0){
  				$query = Video::where('video_id','<>', $id);
  				$query->where('video_catid', $catid);
  				$query->where('video_status', CGlobal::status_show);
  				$query->orderBy('video_id', 'desc');
  				 
  				$fields = (isset($dataField['field_get']) && trim($dataField['field_get']) != '') ? explode(',',trim($dataField['field_get'])): array();
  				if(!empty($fields)){
  					$result = $query->take($limit)->get($fields);
  				}else{
  					$result = $query->take($limit)->get();
  				}
  			}
  			
  		}catch (PDOException $e){
  			throw new PDOException();
  		}
  		return $result;
  	}
    public static function getVideoHot($dataField='', $limit=10){
        $result = array();
        try{
            if($limit > 0){
                $query = Video::where('video_id', '>',0);
				if (isset($dataField['video_hot']) && $dataField['video_hot'] != '') {
					$query->where('video_hot','=', $dataField['video_hot']);
				}
				if (isset($dataField['video_focus']) && $dataField['video_focus'] != '') {
                    $query->where('video_focus','=', $dataField['video_focus']);
                }
				if (isset($dataField['video_catid']) && $dataField['video_catid'] != '') {
					$query->where('video_catid','=', $dataField['video_catid']);
				}
                $query->where('video_status', CGlobal::status_show);
                $query->orderBy('video_order_no', 'asc');

                $fields = (isset($dataField['field_get']) && trim($dataField['field_get']) != '') ? explode(',',trim($dataField['field_get'])): array();
                if(!empty($fields)){
                    $result = $query->take($limit)->get($fields);
                }else{
                    $result = $query->take($limit)->get();
                }
            }

        }catch (PDOException $e){
            throw new PDOException();
        }
        return $result;
    }
}