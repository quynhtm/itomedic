<?php
/*
* @Created by: DUYNX
* @Author    : nguyenduypt86@gmail.com
* @Date      : 06/2016
* @Version   : 1.0
*/
namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\Library\PHPDev\CGlobal;
use App\Library\PHPDev\Memcache;
use App\Library\PHPDev\Utility;

class Images extends Model{
    
    protected $table = 'images';
    protected $primaryKey = 'images_id';
    public  $timestamps = false;
    protected $fillable = array(
	    	'images_id', 'images_catid', 'images_cat_name', 'images_cat_alias','images_title', 'images_title_alias', 'images_intro',
    		'images_content', 'images_image', 'images_image_other','images_created', 'images_hot','images_focus', 'images_order_no',
    		'images_view_num', 'images_name', 'images_address', 'images_yearold', 'images_status', 'meta_title', 'meta_keywords', 'meta_description',
    );
    //ADMIN
  	public static function searchByCondition($dataSearch=array(), $limit=0, $offset=0, &$total){
	  	try{
	  		
	  		$query = Images::where('images_id','>',0);
            if (isset($dataSearch['images_id']) && $dataSearch['images_id'] != '') {
                $query->where('images_id','=', $dataSearch['images_id']);
            }
	  		if (isset($dataSearch['images_id']) && $dataSearch['images_id'] != '') {
	  			$query->where('images_id','=', $dataSearch['images_id']);
	  		}
	  		
	  		if (isset($dataSearch['images_title']) && $dataSearch['images_title'] != '') {
	  			$query->where('images_title','LIKE', '%' . $dataSearch['images_title'] . '%');
	  		}
	  		
	  		if(isset($dataSearch['images_catid']) && $dataSearch['images_catid'] != -1){
	  			$catid = $dataSearch['images_catid'];
	  			$arrCat = array($catid);
	  			Category::makeListCatId($catid, 0, $arrCat);
	  			if(is_array($arrCat) && !empty($arrCat)){
	  				$query->whereIn('images_catid', $arrCat);
	  			}
	  		}
	  		
	  		if (isset($dataSearch['images_status']) && $dataSearch['images_status'] != -1){
	  			$query->where('images_status', $dataSearch['images_status']);
	  		}
	  		
	  		if (isset($dataSearch['images_hot']) && $dataSearch['images_hot'] != -1) {
	  			$query->where('images_hot', $dataSearch['images_hot']);
	  		}
	  		
	  		if (isset($dataSearch['images_focus']) && $dataSearch['images_focus'] != -1) {
	  			$query->where('images_focus', $dataSearch['images_focus']);
	  		}
	  		
	  		$total = $query->count();
	  		$query->orderBy('images_id', 'desc');
	  	
	  		$fields = (isset($dataSearch['field_get']) && trim($dataSearch['field_get']) != '') ? explode(',',trim($dataSearch['field_get'])): array();
	  		if(!empty($fields)){
	  			$result = $query->take($limit)->skip($offset)->get($fields);
	  		}else{
	  			$result = $query->take($limit)->skip($offset)->get();
	  		}
	  		return $result;
	  	
	  	}catch (PDOException $e){
	  		throw new PDOException();
	  	}
  	}
  	
  	public static function getById($id=0){
  		$result = (Memcache::CACHE_ON) ? Cache::get(Memcache::CACHE_IMAGES_ID.$id) : array();
  		try {
  			if(empty($result)){
	  			$result = Images::where('images_id', $id)->first();
	  			if($result && Memcache::CACHE_ON){
	  				Cache::put(Memcache::CACHE_IMAGES_ID.$id, $result, Memcache::CACHE_TIME_TO_LIVE_ONE_MONTH);
	  			}
	  		}
	  	} catch (PDOException $e) {
	  		throw new PDOException();
	  	}
	  	return $result;
  	}
  	
  	public static function updateData($id=0, $dataInput=array()){
  		try {
  			DB::connection()->getPdo()->beginTransaction();
  			$data = Images::find($id);
  			if($id > 0 && !empty($dataInput)){
  				$data->update($dataInput);
  				if(isset($data->images_id) && $data->images_id > 0){
  					self::removeCacheId($data->images_id);
  				}
  			}
  			DB::connection()->getPdo()->commit();
  			return true;
  		} catch (PDOException $e) {
  			DB::connection()->getPdo()->rollBack();
  			throw new PDOException();
  		}
  	}
  	
  	public static function addData($dataInput=array()){
        try {
            DB::connection()->getPdo()->beginTransaction();
            $data = new Images();
            if (is_array($dataInput) && count($dataInput) > 0) {
                foreach ($dataInput as $k => $v) {
                    $data->$k = $v;
                }
            }
            if ($data->save()) {
                DB::connection()->getPdo()->commit();
                if($data->images_id && Memcache::CACHE_ON){
                	images::removeCacheId($data->images_id);
                }
                return $data->images_id;
            }
            DB::connection()->getPdo()->commit();
            return false;
        } catch (PDOException $e) {
            DB::connection()->getPdo()->rollBack();
            throw new PDOException();
        }
    }

    public static function saveData($id=0, $data=array()){
    	$data_post = array();
    	if(!empty($data)){
    		foreach($data as $key=>$val){
    			$data_post[$key] = $val['value'];
    		}
    	}
    	if($id > 0){
    		Images::updateData($id, $data_post);
    		Utility::messages('messages', 'Cập nhật thành công!');
    	}else{
            Images::addData($data_post);
    		Utility::messages('messages', 'Thêm mới thành công!');
    	}
 
    }
    
  	public static function deleteId($id=0){
  		try {
  			DB::connection()->getPdo()->beginTransaction();
  			$data = Images::find($id);
  			if($data != null){
  				//Remove Img
  				$images_image_other = ($data->images_image_other != '') ? unserialize($data->images_image_other) : array();
  				if(is_array($images_image_other) && !empty($images_image_other)){
  					$path = Config::get('config.DIR_ROOT').'uploads/'.CGlobal::FOLDER_IMAGES.'/'.$id;
  					foreach($images_image_other as $v){
  						if(is_file($path.'/'.$v)){
  							@unlink($path.'/'.$v);
  						}
  					}
  					if(is_dir($path)) {
  						@rmdir($path);
  					}
  				}
  				//End Remove Img
  				$data->delete();
  				if(isset($data->images_id) && $data->images_id > 0){
  					self::removeCacheId($data->images_id);
  				}
  				DB::connection()->getPdo()->commit();
  			}
  			return true;
  		} catch (PDOException $e) {
  			DB::connection()->getPdo()->rollBack();
  			throw new PDOException();
  		}
  	}
  	
  	public static function removeCacheId($id=0){
  		if($id>0){
  			Cache::forget(Memcache::CACHE_IMAGES_ID.$id);
  		}
  	}
  	
  	//SITE
    public static function getImagesHot($dataField='', $limit=10){
        $result = array();
        try{
            if($limit > 0){
                $query = Images::where('images_id', '>',0);
                if (isset($dataField['images_focus']) && $dataField['images_focus'] != '') {
                    $query->where('images_focus', '=', $dataField['images_focus']);
                }
				if (isset($dataField['images_catid']) && $dataField['images_catid'] != '') {
					$query->where('images_catid', '=', $dataField['images_catid']);
				}
                $query->where('images_status', CGlobal::status_show);
                $query->orderBy('images_id', 'desc');

                $fields = (isset($dataField['field_get']) && trim($dataField['field_get']) != '') ? explode(',',trim($dataField['field_get'])): array();
                if(!empty($fields)){
                    $result = $query->take($limit)->get($fields);
                }else{
                    $result = $query->take($limit)->get();
                }
            }

        }catch (PDOException $e){
            throw new PDOException();
        }
        return $result;
    }
    public static function getSameImages($dataField='', $catid=0, $id=0, $limit=10){
  		$result = array();
  		try{
  			if($catid > 0 && $id > 0 && $limit > 0){
  				$query = Images::where('images_id','<>', $id);
  				$query->where('images_catid', $catid);
  				$query->where('images_status', CGlobal::status_show);
  				$query->orderBy('images_id', 'desc');
  				 
  				$fields = (isset($dataField['field_get']) && trim($dataField['field_get']) != '') ? explode(',',trim($dataField['field_get'])): array();
  				if(!empty($fields)){
  					$result = $query->take($limit)->get($fields);
  				}else{
  					$result = $query->take($limit)->get();
  				}
  			}
  			
  		}catch (PDOException $e){
  			throw new PDOException();
  		}
  		return $result;
  	}
}