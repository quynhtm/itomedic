<?php
/*
* @Created by: HSS
* @Author	 : nguyenduypt86@gmail.com
* @Date 	 : 08/2016
* @Version	 : 1.0
*/
namespace App\Library\PHPDev;

class CGlobal{
    static $cssVer = 1.0;
    static $jsVer = 1.0;

    //Position Header, Footer
    public static $postHead = 1;
    public static $postEnd = 2;

    //Add CSS, JS, Meta
    public static $extraHeaderCSS = '';
    public static $extraHeaderJS = '';
    public static $extraFooterCSS = '';
    public static $extraFooterJS = '';
    public static $extraMeta = '';

    //Dev
    const is_dev = 0;

    //Role
    const rid_admin = 1;
    const rid_manager = 2;
    const rid_cskh = 3;
    const rid_goihang = 4;

    const domain = 'itovn.com.vn';
    const nameSite = 'Dòng thông tin Công ty TNHH Thiết bị y tế ITO Việt Nhật';
    const phoneSupport = '094.11.99.656 - 0913.922.986';
    const emailAdmin = 'nguyenduypt86@gmail.com';

    const txt403 = 'Không được truy cập...';
    const txt404 = 'Không tìm thấy...';

    const num_record_per_page = 30;
    const num_scroll_page = 2;

    const num_record_per_page_product_home = 25;
    const num_record_per_page_product = 9;
    const num_record_same_product = 10;
    const num_record_product_hot_random = 5;

    const num_record_per_page_news = 12;
    const num_record_same_news = 5;

    const status_hide = 0;
    const status_show = 1;

    const product_sale_off = 0;
    const product_sale_on = 1;
    //Size Img
    public static $arrSizeImg = array(
        '2'=>'200x200',
        '4'=>'400x400',
        '6'=>'600x600',
        '8'=>'800x800',
    );

    //Folder
    const IMAGE_ERROR = 133;
    const FOLDER_BANNER = 'banner';
    const FOLDER_NEWS = 'news';
    const FOLDER_PRODUCT = 'product';
    const FOLDER_CATEGORY = 'category';
    const FOLDER_TRASH = 'trash';
    const FOLDER_INFO = 'info';
    const FOLDER_STATICS = 'statics';
    const FOLDER_IMAGES = 'images';
    const FOLDER_VIDEO = 'video';
    const FOLDER_HOIDAP = 'hoidap';

    //Link order Partner
    const link_order_shipchung = '';
    const link_order_viettel = '';
    const link_order_goldship = '';


    const catIDGiftFree = 548;
    const catIDTriNamNatame = 543;

    //Api Key Facebook
    const facebook_app_id = '';
    const facebook_app_secret = '';
    const facebook_default_graph_version = 'v2.8';
    const facebook_persistent_data_handler = 'session';

    //Api Key Google
    const googe_client_id = '';
    const googe_client_secret = '';

    //Danh sach chuc vu
    public static $arrChucVu = array(
        '1'=>'Bác sỹ tư vấn',
        '2'=>'Dược sỹ tư vấn',
        '3'=>'Y sĩ tư vấn',
        '4'=>'Tư vấn bán hàng',
        '5'=>'Trợ lý giám đốc',
        '6'=>'Nhân viên chăm sóc page',
        '7'=>'Nhân viên chăm sóc khách hàng',
        '8'=>'Chuyên viên nhân sự',
        '9'=>'Nhân viên code web',
        '10'=>'Tư vấn inbox facebook',
        '11'=>'Trưởng phòng marketing',
        '12'=>'Nhân viên thiết kế',
        '13'=>'Nhân viên kho',
        '14'=>'Nhân viên content',
    );


}